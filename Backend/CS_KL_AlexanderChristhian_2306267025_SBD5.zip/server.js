require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Import Routes
const storeRoutes = require('./routes/storeRoutes')();
const userRoutes = require('./routes/userRoutes')();
app.use('/store', storeRoutes);
app.use('/user', userRoutes);

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
