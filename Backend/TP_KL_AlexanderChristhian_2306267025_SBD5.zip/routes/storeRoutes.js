const express = require('express');
const storeController = require('../controllers/storeController');

module.exports = () => {
    const router = express.Router();

    router.get('/getAll', storeController.getAllStores);
    router.post('/create', storeController.createStore);

    return router;
};
