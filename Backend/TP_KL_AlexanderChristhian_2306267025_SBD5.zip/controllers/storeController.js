const pool = require('../database/pg-database'); // Import the pool module

// Get all stores
const getAllStores = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM stores ORDER BY created_at DESC');
    res.json({
      success: true,
      message: 'Stores found',
      payload: result.rows,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching stores',
      error: error.message,
    });
  }
};

// Create a new store
const createStore = async (req, res) => {
  try {
    const { name, address } = req.body;

    if (!name || !address) {
      return res.status(400).json({
        success: false,
        message: 'Missing store name or address',
        payload: null,
      });
    }

    const result = await pool.query(
      'INSERT INTO stores (name, address) VALUES ($1, $2) RETURNING *',
      [name, address]
    );

    res.status(201).json({
      success: true,
      message: 'Store created',
      payload: result.rows[0],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating store',
      error: error.message,
    });
  }
};

module.exports = { getAllStores, createStore };
