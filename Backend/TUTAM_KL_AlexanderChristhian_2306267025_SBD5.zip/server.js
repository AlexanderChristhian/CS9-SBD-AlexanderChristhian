require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const cloudinary = require('cloudinary').v2;

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Import Routes
const storeRoutes = require('./routes/storeRoutes')();
const userRoutes = require('./routes/userRoutes')();
const itemRoutes = require('./routes/itemRoutes')();
app.use('/store', storeRoutes);
app.use('/user', userRoutes);
app.use('/item', itemRoutes);

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
