const pool = require('../database/pg-database'); // Import the pool module

const registerUser = async (req, res) => {
    const { email, password, name, balance } = req.query;

    try {
        const existingUser = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (existingUser.rows.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Email already used",
                payload: null,
            });
        }
        const result = await pool.query(
            'INSERT INTO users (email, password, name, balance) VALUES ($1, $2, $3, $4) RETURNING *',
            [email, password, name, balance]
        );
        const user = result.rows[0];
        res.status(201).json({
            success: true,
            message: "User created",
            payload: result.rows[0],
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

const loginUser = async (req, res) => {
    const { email, password } = req.query;

    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1 AND password = $2', [email, password]);
        if (result.rows.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Invalid email or password",
                payload: null,
            });
        }
        res.json({
            success: true,
            message: "Login successful",
            payload: result.rows[0],
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

const findUser = async (req, res) => {
    const email = req.params.email;
    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "User not found",
                payload: null,
            });
        }
        res.json({
            success: true,
            message: "User found",
            payload: result.rows,
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

const updateUser = async (req, res) => {
    const { id, email, password, name, balance } = req.body;

    try {
        const result = await pool.query(
            'UPDATE users SET email = $2, password = $3, name = $4, balance = $5 WHERE id = $1 RETURNING *',
            [id, email, password, name, balance]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "User not found",
                payload: null,
            });
        }
        res.json({
            success: true,
            message: "User updated",
            payload: result.rows[0],
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

const deleteUser = async (req, res) => {
    const id = req.params.id;

    try {
        const result = await pool.query('DELETE FROM users WHERE id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "User not found",
                payload: null,
            });
        }
        res.json({
            success: true,
            message: "User deleted",
            payload: result.rows[0],
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

module.exports = { registerUser, loginUser, findUser, updateUser, deleteUser }; 