require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const cloudinary = require('cloudinary').v2;

const app = express();
const PORT = process.env.PORT || 5000;

const corsOptions = {
  origin: 'https://os.netlabdte.com', // Allow domain ini
  methods: ['GET', 'POST', 'PUT', 'DELETE'], // mengallow HTTP ini
};

// Middleware
app.use(cors(corsOptions));
app.use(bodyParser.json());

// Import Routes
const storeRoutes = require('./routes/storeRoutes')();
const userRoutes = require('./routes/userRoutes')();
const itemRoutes = require('./routes/itemRoutes')();
const transactionRoutes = require('./routes/transactionRoutes')();
app.use('/store', storeRoutes);
app.use('/user', userRoutes);
app.use('/item', itemRoutes);
app.use('/transaction', transactionRoutes);

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
